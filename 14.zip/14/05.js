<script>
function product(a, b)
{
	return a*b
}
</script>
