ALTER TABLE classics ADD INDEX(author(20));
CREATE INDEX author ON classics (author(20));
