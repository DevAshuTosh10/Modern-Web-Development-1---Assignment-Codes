SELECT COUNT(*) FROM classics;
