<?php
  echo file_get_contents("http://oreilly.com");
?>
