<?php 
	
	// input array 
	$state = array("AS"=>"ASSAM", "OR"=>"ORISSA", "KR"=>"KERALA"); 
	
	extract($state); 
	
	// after using extract() function 
	echo"\$AS is $AS\n\$KR is $KR\n\$OR is $OR"; 
	
    $AS="Original"; 
      
    $state = array("AS"=>"ASSAM", "OR"=>"ORISSA", "KR"=>"KERALA"); 
      
    // handling collisions with extract() function 
    extract($state, EXTR_PREFIX_SAME, "dup"); 
      
    echo"\$AS is $AS\n\$KR is $KR\n\$OR if $OR \n\$dup_AS = $dup_AS"; 

?> 
