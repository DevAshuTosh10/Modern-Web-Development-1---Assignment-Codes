<?php

$my_array = array("red","green","blue","yellow","purple");

shuffle($my_array);
print_r($my_array);

?>
