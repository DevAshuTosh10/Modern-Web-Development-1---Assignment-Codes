<?php

$my_array = array("Dog","Cat","Horse");
list($a, $b, $c) = $my_array;
echo "I have several animals, a $a, a $b and a $c.";


$a = "Hello world!";
echo "The value of variable 'a' before unset: " . $a . "<br>";
unset($a);
echo "The value of variable 'a' after unset: " . $a;


echo(max(2,4,6,8,10) . "<br>");
echo(max(22,14,68,18,15) . "<br>");
echo(max(array(4,6,8,10)) . "<br>");
echo(max(array(44,16,81,12)));

$a=array("Volvo"=>"XC90","BMW"=>"X5","Toyota"=>"Highlander");
print_r(array_keys($a));

$a=array("Name"=>"Peter","Age"=>"41","Country"=>"USA");
print_r(array_values($a));

$a1=array("red","green");
$a2=array("blue","yellow");
print_r(array_merge($a1,$a2));

$a=array("a"=>"red","b"=>"green","c"=>"blue");
echo array_search("red",$a);

$age=array("Peter"=>"35","Ben"=>"37","Joe"=>"43");
print_r(array_change_key_case($age,CASE_UPPER));

$cars=array("Volvo","BMW","Toyota");
echo sizeof($cars);
?>


