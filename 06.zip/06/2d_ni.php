<?php 

// PHP program to creating three 
// dimensional array 

// Create three nested array 
$myarray = array( 
 
		array(1, 2), 
		array(3, 4), 
		array(5, 6), 
		array(7, 8), 
	
); 
	
// Display the array information 
//print_r($myarray); 

for($i=0;$i<4;$i++){
	for($j=0;$j<2;$j++){
    echo $myarray[$i][$j], "<br>";
}
}

for($i=0;$i<count ($myarray);$i++){
	for($j=0;$j<count ($myarray[$i]);$j++){
    echo $myarray[$i][$j], "<br>";
}
}



foreach ($myarray as $b)	//before $a value as $b
	{
		foreach ($b as $c)
		{
			echo $c , "<br>";
		}
	}	echo "<br>";
?> 
