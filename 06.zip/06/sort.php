<?php 

$cars = array("Volvo", "BMW", "Toyota");
sort($cars);
sort($cars, 1);

$cars=array("Volvo","BMW","Toyota");
rsort($cars);
sort($cars, 2);

?>


