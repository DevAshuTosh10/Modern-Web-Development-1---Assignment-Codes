<?php
  $temp = explode('***', "A***sentence***with***asterisks");
  print_r($temp);
?>
